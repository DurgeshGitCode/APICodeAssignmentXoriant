package package1;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class PostExamples {
	
	public String readPostBody() throws FileNotFoundException {
		  File myObj = new File("C:\\API_Practice\\APIProject\\src\\test\\java\\packageAPITest\\PostRequestBody.txt");
	      Scanner myReader = new Scanner(myObj);
	      String data = "";
	      while (myReader.hasNextLine()) {
	        data = data + myReader.nextLine();
	      }
	      myReader.close();
	      return data;
	}
	
	@Test
	@Parameters({"nameToValidate","jobToBeUsed"})
	public void createUser(String nameToBeUpdated, String jobToBeUpdated) throws FileNotFoundException {
		
		String payLoadData = readPostBody();
		payLoadData = payLoadData.replaceAll("nameToValidate", nameToBeUpdated);
		payLoadData = payLoadData.replaceAll("jobToBeUsed", jobToBeUpdated);
		given().contentType(ContentType.JSON).body(payLoadData).then().statusCode(201);
	}

}
