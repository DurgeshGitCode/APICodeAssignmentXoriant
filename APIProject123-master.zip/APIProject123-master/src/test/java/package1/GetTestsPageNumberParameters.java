package package1;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import static org.hamcrest.Matchers.*;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;

public class GetTestsPageNumberParameters {

	@Parameters("pageNumber")
	public void getListOfUsersUsingPageNumberParam(int pageNumber) {
		RestAssured.baseURI="https://reqres.in";
		RestAssured.basePath="/api/users";
		RestAssured.rootPath="data";
		RequestSpecification reqSpec=RestAssured.given();
		reqSpec.headers("content-type","application/json");
		reqSpec.queryParam("page", pageNumber);
		reqSpec.get().then().body("id", hasItems(7));
			
	}

	@Parameters("pageNumber")
	@Test
	public void getListOfUsersQueryParam(int pageNumber) {
		RestAssured.baseURI="https://reqres.in";
		RestAssured.basePath="/api/users";
		RequestSpecification reqSpec=RestAssured.given();
		reqSpec.queryParam("page", pageNumber);
		String respInString=reqSpec.get().body().asString();
		System.out.println(respInString);
		
		//Durgesh Code
		Assert.assertTrue(respInString.contains("page"));
		Assert.assertTrue(respInString.contains("per_page"));
		Assert.assertTrue(respInString.contains("total"));
		Assert.assertTrue(respInString.contains("total_pages"));
		Assert.assertTrue(respInString.contains("data"));
		Assert.assertTrue(respInString.contains("ad"));
	}
}
